<?php

namespace FenaCommerceGateway;

class AdminPortalUI
{
    public static function get($settings)
    {

        ?>
        <h2>Fena Payment Gateway</h2>
        <table class="form-table">
            <?php echo $settings; ?>
        </table>

        <h4>Payment Notification URL</h4>
        <pre><?php echo home_url('/wc-api/fena', 'https'); ?></pre>

        <h4>Redirect URL</h4>
        <pre><?php echo wc_get_endpoint_url('order-received', '', wc_get_checkout_url()); ?></pre>
        <script>
    document.addEventListener('DOMContentLoaded', function() {
        var dropdown = document.getElementById('woocommerce_fena_payment_dropdown');
        var terminalSecretField = document.getElementById('woocommerce_fena_payment_terminal_secret');
        var terminalIdField = document.getElementById('woocommerce_fena_payment_terminal_id');
        var bankDetails = {}; //Assign a global Variable so we can give the values comming from end point to it. 
        
            if (terminalIdField.value && terminalSecretField.value) {
                // Make an API call to fetch the data
                // Replace 'apiEndpoint' with the actual API endpoint URL
                fetch('https://epos.api.fena.co/open/company/bank-accounts/list', {
  headers: {
    'secret-key': terminalSecretField.value ,
    'integration-id': terminalIdField.value
  }
}).then(response => {
    if (!response.ok) {
      throw new Error('Network response was not OK.');
    }
    return response.json();
  })
  .then(data => {
    const banks = {};
    const name = data.data.map(item => item.name);
    data.data.forEach(item => {
      banks[item.name] = item._id;
      
    });
     bankDetails = banks; //assin the got value to the global value. 
     
                        
                        dropdown.innerHTML = ""; 
                        name.forEach(option => {
                           const newOption = document.createElement("option");
                            newOption.value = option;
                            newOption.text = option;
                           dropdown.appendChild(newOption);
});
  })
  .catch(error => console.error("Error fetching data:", error));

 const select = document.getElementById('woocommerce_fena_payment_dropdown');
    select.addEventListener('change', function handleChange(event) {
         selected    =   event.target.value;
         const selectedBankId = bankDetails[selected]; //extract the ID from the saved bankdetails global
         console.log(selectedBankId);   


     var selectedBank = document.getElementById('woocommerce_fena_payment_selected_bank');
     var selectedBankID = document.getElementById('woocommerce_fena_payment_selected_bankId');

     selectedBank.value = selected;
     selectedBankID.value = selectedBankId;

});
               
        }
       

   });
</script>

        <?php
    }
}
